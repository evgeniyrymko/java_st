CREATE FUNCTION `AverageAge`(`mark` VARCHAR(45))
  RETURNS DOUBLE
BEGIN
    RETURN (SELECT AVG(cl.age) FROM clients cl 
            INNER JOIN orders o ON cl.id = o.client_id
			INNER JOIN cars c ON c.id = o.car_id
            INNER JOIN marks m ON c.mark_id = m.id WHERE m.mark = mark);
END