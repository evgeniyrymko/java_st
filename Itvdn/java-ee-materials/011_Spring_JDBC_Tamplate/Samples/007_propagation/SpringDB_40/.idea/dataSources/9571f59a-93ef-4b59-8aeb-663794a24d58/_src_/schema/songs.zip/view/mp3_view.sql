CREATE VIEW `mp3_view` AS
  SELECT
    `a`.`name` AS `author_name`,
    `a`.`id`   AS `author_id`,
    `m`.`name` AS `mp3_name`,
    `m`.`id`   AS `mp3_id`
  FROM (`songs`.`mp3` `m`
    JOIN `songs`.`author` `a` ON ((`m`.`author_id` = `a`.`id`)))