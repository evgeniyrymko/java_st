package by.rymko.openapigeneratorgradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenApiGeneratorGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenApiGeneratorGradleApplication.class, args);
	}

}
