package by.rymko.openapigeneratorgradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenApiGeneratorGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
